prompt PL/SQL Developer Export Tables for user %SCHEMA%
prompt Created by %OSUSER% on %DATETIME%
set feedback off
set define off
