prompt PL/SQL Developer Export User Objects for user %SCHEMA%
prompt Created by %OSUSER% on %DATETIME%
set define off
spool %FILENAME%.log

