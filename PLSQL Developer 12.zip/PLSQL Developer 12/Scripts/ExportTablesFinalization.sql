set feedback on
set define on
prompt Done

